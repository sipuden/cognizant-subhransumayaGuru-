package exercise4;


public interface PaymentProcessor {
    void processPayment(double amount);

}
