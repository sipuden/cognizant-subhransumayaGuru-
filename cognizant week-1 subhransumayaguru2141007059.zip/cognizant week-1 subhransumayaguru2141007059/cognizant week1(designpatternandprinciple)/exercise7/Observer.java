package exercise7;

// Observer.java
public interface Observer {
    void update(double stockPrice);
}
